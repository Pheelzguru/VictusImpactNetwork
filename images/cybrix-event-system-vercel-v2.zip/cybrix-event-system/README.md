# CybriX Smart Event Attendance & Certificate System

A Flask web application for participant management, QR-code check-in, live
attendance monitoring, PDF certificate generation and certificate verification.

## Quick start on Windows

1. Open the `cybrix-event-system` folder in VS Code.
2. Open **Terminal > New Terminal**.
3. Create a virtual environment:

   ```powershell
   py -m venv venv
   ```

4. Activate it:

   ```powershell
   venv\Scripts\activate
   ```

5. Install the packages:

   ```powershell
   pip install -r requirements.txt
   ```

6. Copy `.env.example` to `.env`.
7. Start the application:

   ```powershell
   python run.py
   ```

8. Open `http://127.0.0.1:5000`.

Default admin login:

- Username: `admin`
- Password: `admin123`

Change these values in `.env` before using the system publicly.

## First-time setup

1. Log in as admin.
2. Open **Events** and create the active event.
3. Add participants manually or import `sample_participants.csv`.
4. Download the universal QR code from the dashboard.
5. Participants scan the QR code and check in with their ID and phone number.
6. Download verified attendees' certificates from the dashboard.

## Using MySQL

Create a MySQL database named `cybrix_event`, then change `DATABASE_URL` in
`.env`:

```env
DATABASE_URL=mysql+pymysql://root:your_password@localhost/cybrix_event
```

Restart the application. Flask will create the required tables automatically.

## Deploying on Vercel

This version includes `api/index.py` and `vercel.json` for Vercel deployment.
Because Vercel functions do not use local SQLite for permanent event data,
connect the project to a Neon PostgreSQL database through the Vercel Marketplace.

Set these environment variables in Vercel:

```env
DATABASE_URL=provided-automatically-by-neon
SECRET_KEY=use-a-long-random-value
ADMIN_USERNAME=admin
ADMIN_PASSWORD=use-a-strong-password
BASE_URL=https://your-project.vercel.app
```

Deploy once to obtain the Vercel address, add `BASE_URL`, and redeploy. Log into
the deployed admin area, create the event, import the cleaned participant CSV,
and download a new QR code.

## CSV columns

The importer accepts these headings:

```text
full_name,phone,email,department,area_of_interest
```

Google Forms headings such as `Full Name`, `Phone Number`, `Email Address`,
`Department`, and `Area of Interest` are also accepted.
