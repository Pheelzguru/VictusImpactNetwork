import csv
import io
from datetime import datetime, timezone
from flask import (
    Blueprint, current_app, flash, redirect, render_template, request,
    send_file, session, url_for
)
from sqlalchemy import func
from .decorators import admin_required
from .extensions import db
from .models import Attendance, Event, Participant
from .utils import (
    build_certificate, create_participant_code, make_qr_png, normalize_phone
)

main = Blueprint("main", __name__)


def active_event():
    return Event.query.filter_by(is_active=True).order_by(Event.id.desc()).first()


def clean_csv_row(row):
    return {
        (key or "").strip().lower().replace(" ", "_"): (value or "").strip()
        for key, value in row.items()
    }


@main.route("/")
def home():
    return render_template("home.html", event=active_event())


@main.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if (
            username == current_app.config["ADMIN_USERNAME"]
            and password == current_app.config["ADMIN_PASSWORD"]
        ):
            session["admin_logged_in"] = True
            return redirect(url_for("main.dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@main.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.login"))


@main.route("/check-in", methods=["GET", "POST"])
def check_in():
    event = active_event()
    if request.method == "POST":
        if not event:
            flash("No active event is available for check-in.", "danger")
            return redirect(url_for("main.check_in"))

        code = request.form.get("participant_id", "").strip().upper()
        phone = normalize_phone(request.form.get("phone", ""))
        participant = Participant.query.filter_by(participant_id=code).first()

        if not participant or normalize_phone(participant.phone) != phone:
            flash("Participant ID or phone number is incorrect.", "danger")
            return redirect(url_for("main.check_in"))

        existing = Attendance.query.filter_by(
            participant_id=participant.id, event_id=event.id
        ).first()
        if existing:
            return render_template(
                "checkin_result.html",
                participant=participant,
                event=event,
                duplicate=True,
                attendance=existing,
            )

        attendance = Attendance(participant_id=participant.id, event_id=event.id)
        db.session.add(attendance)
        db.session.commit()
        return render_template(
            "checkin_result.html",
            participant=participant,
            event=event,
            duplicate=False,
            attendance=attendance,
        )

    return render_template("checkin.html", event=event)


@main.route("/admin/dashboard")
@admin_required
def dashboard():
    event = active_event()
    registered = Participant.query.count()
    attended = 0
    recent = []
    if event:
        attended = Attendance.query.filter_by(event_id=event.id).count()
        recent = (
            Attendance.query.filter_by(event_id=event.id)
            .order_by(Attendance.checked_in_at.desc())
            .limit(10)
            .all()
        )
    percentage = round((attended / registered * 100), 1) if registered else 0
    return render_template(
        "dashboard.html",
        event=event,
        registered=registered,
        attended=attended,
        absent=max(registered - attended, 0),
        percentage=percentage,
        recent=recent,
    )


@main.route("/admin/events", methods=["GET", "POST"])
@admin_required
def events():
    if request.method == "POST":
        Event.query.update({"is_active": False})
        event = Event(
            name=request.form["name"].strip(),
            event_date=request.form["event_date"].strip(),
            venue=request.form.get("venue", "").strip(),
            is_active=True,
        )
        db.session.add(event)
        db.session.commit()
        flash("Event created and activated.", "success")
        return redirect(url_for("main.events"))
    return render_template("events.html", events=Event.query.order_by(Event.id.desc()).all())


@main.post("/admin/events/<int:event_id>/activate")
@admin_required
def activate_event(event_id):
    Event.query.update({"is_active": False})
    event = db.get_or_404(Event, event_id)
    event.is_active = True
    db.session.commit()
    flash(f"{event.name} is now active.", "success")
    return redirect(url_for("main.events"))


@main.route("/admin/participants")
@admin_required
def participants():
    search = request.args.get("search", "").strip()
    query = Participant.query
    if search:
        pattern = f"%{search}%"
        query = query.filter(
            db.or_(
                Participant.full_name.ilike(pattern),
                Participant.participant_id.ilike(pattern),
                Participant.phone.ilike(pattern),
            )
        )
    return render_template(
        "participants.html",
        participants=query.order_by(Participant.id.desc()).all(),
        search=search,
    )


@main.route("/admin/participants/add", methods=["GET", "POST"])
@admin_required
def add_participant():
    if request.method == "POST":
        next_number = (db.session.query(func.max(Participant.id)).scalar() or 0) + 1
        participant = Participant(
            participant_id=create_participant_code(next_number),
            full_name=request.form["full_name"].strip(),
            phone=request.form["phone"].strip(),
            email=request.form.get("email", "").strip(),
            department=request.form.get("department", "").strip(),
            area_of_interest=request.form.get("area_of_interest", "").strip(),
        )
        db.session.add(participant)
        db.session.commit()
        flash(f"Participant added with ID {participant.participant_id}.", "success")
        return redirect(url_for("main.participants"))
    return render_template("participant_form.html")


@main.route("/admin/participants/import", methods=["GET", "POST"])
@admin_required
def import_participants():
    if request.method == "POST":
        uploaded = request.files.get("file")
        if not uploaded or not uploaded.filename.lower().endswith(".csv"):
            flash("Please select a CSV file.", "danger")
            return redirect(url_for("main.import_participants"))

        text = io.TextIOWrapper(uploaded.stream, encoding="utf-8-sig")
        rows = csv.DictReader(text)
        created = 0
        skipped = 0
        next_number = (db.session.query(func.max(Participant.id)).scalar() or 0) + 1

        existing_phones = {
            normalize_phone(phone)
            for (phone,) in db.session.query(Participant.phone).all()
        }

        for original_row in rows:
            row = clean_csv_row(original_row)
            name = row.get("full_name", "")
            phone = row.get("phone") or row.get("phone_number", "")
            if not name or not phone:
                skipped += 1
                continue
            normalized_phone = normalize_phone(phone)
            if not normalized_phone or normalized_phone in existing_phones:
                skipped += 1
                continue
            participant = Participant(
                participant_id=create_participant_code(next_number),
                full_name=name,
                phone=phone,
                email=row.get("email") or row.get("email_address", ""),
                department=row.get("department", ""),
                area_of_interest=row.get("area_of_interest", ""),
            )
            db.session.add(participant)
            existing_phones.add(normalized_phone)
            created += 1
            next_number += 1
        db.session.commit()
        flash(f"Imported {created} participants; skipped {skipped}.", "success")
        return redirect(url_for("main.participants"))
    return render_template("import.html")


@main.route("/admin/qr-code")
@admin_required
def qr_code():
    configured_url = current_app.config.get("BASE_URL", "").rstrip("/")
    if configured_url and "127.0.0.1" not in configured_url and "localhost" not in configured_url:
        public_url = configured_url
    else:
        public_url = request.url_root.rstrip("/")
    checkin_url = f"{public_url}{url_for('main.check_in')}"
    return send_file(
        make_qr_png(checkin_url),
        mimetype="image/png",
        download_name="cybrix-attendance-qr.png",
    )


@main.route("/certificate/<int:event_id>/<int:participant_id>")
def certificate(event_id, participant_id):
    event = db.get_or_404(Event, event_id)
    participant = db.get_or_404(Participant, participant_id)
    attendance = Attendance.query.filter_by(
        event_id=event.id, participant_id=participant.id
    ).first_or_404()
    verification_url = url_for(
        "main.verify_certificate",
        event_id=event.id,
        participant_id=participant.id,
        _external=True,
    )
    pdf, certificate_number = build_certificate(participant, event, verification_url)
    safe_name = "-".join(participant.full_name.lower().split())
    return send_file(
        pdf,
        mimetype="application/pdf",
        as_attachment=True,
        download_name=f"{safe_name}-{certificate_number}.pdf",
    )


@main.route("/verify/<int:event_id>/<int:participant_id>")
def verify_certificate(event_id, participant_id):
    attendance = Attendance.query.filter_by(
        event_id=event_id, participant_id=participant_id
    ).first()
    return render_template("verify.html", attendance=attendance)
