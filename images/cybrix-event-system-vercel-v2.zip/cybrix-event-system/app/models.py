from datetime import datetime, timezone
from .extensions import db


class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(180), nullable=False)
    event_date = db.Column(db.String(50), nullable=False)
    venue = db.Column(db.String(180), default="")
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    attendances = db.relationship(
        "Attendance", backref="event", lazy=True, cascade="all, delete-orphan"
    )


class Participant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    participant_id = db.Column(db.String(20), unique=True, nullable=False, index=True)
    full_name = db.Column(db.String(180), nullable=False)
    phone = db.Column(db.String(30), nullable=False, index=True)
    email = db.Column(db.String(180), default="")
    department = db.Column(db.String(180), default="")
    area_of_interest = db.Column(db.String(180), default="")
    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    attendances = db.relationship(
        "Attendance", backref="participant", lazy=True, cascade="all, delete-orphan"
    )


class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    participant_id = db.Column(
        db.Integer, db.ForeignKey("participant.id"), nullable=False
    )
    event_id = db.Column(db.Integer, db.ForeignKey("event.id"), nullable=False)
    checked_in_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    __table_args__ = (
        db.UniqueConstraint(
            "participant_id", "event_id", name="unique_participant_event"
        ),
    )

