import io
import re
import qrcode
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas


def normalize_phone(phone):
    digits = re.sub(r"\D", "", str(phone or ""))
    if digits.startswith("234") and len(digits) >= 13:
        digits = digits[3:]
    if digits.startswith("0") and len(digits) == 11:
        digits = digits[1:]
    return digits


def create_participant_code(number):
    return f"CYB{number:04d}"


def make_qr_png(data):
    image = qrcode.make(data)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer


def build_certificate(participant, event, verification_url):
    buffer = io.BytesIO()
    width, height = landscape(A4)
    pdf = canvas.Canvas(buffer, pagesize=(width, height))

    pdf.setFillColor(colors.HexColor("#071A3D"))
    pdf.rect(0, 0, width, height, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor("#0E2A5D"))
    pdf.roundRect(28, 28, width - 56, height - 56, 22, fill=1, stroke=0)
    pdf.setStrokeColor(colors.HexColor("#19B8FF"))
    pdf.setLineWidth(3)
    pdf.roundRect(42, 42, width - 84, height - 84, 18, fill=0, stroke=1)

    pdf.setFillColor(colors.white)
    pdf.setFont("Helvetica-Bold", 22)
    pdf.drawCentredString(width / 2, height - 105, "CYBRIX SOLUTIONS")
    pdf.setFillColor(colors.HexColor("#19B8FF"))
    pdf.setFont("Helvetica-Bold", 38)
    pdf.drawCentredString(width / 2, height - 165, "CERTIFICATE OF ATTENDANCE")

    pdf.setFillColor(colors.white)
    pdf.setFont("Helvetica", 17)
    pdf.drawCentredString(width / 2, height - 220, "This certificate is proudly presented to")
    pdf.setFont("Helvetica-Bold", 30)
    pdf.drawCentredString(width / 2, height - 275, participant.full_name)
    pdf.setStrokeColor(colors.HexColor("#19B8FF"))
    pdf.line(width / 2 - 210, height - 288, width / 2 + 210, height - 288)

    pdf.setFont("Helvetica", 16)
    pdf.drawCentredString(width / 2, height - 330, f"for attending {event.name}")
    pdf.drawCentredString(width / 2, height - 360, f"held on {event.event_date}")

    certificate_number = f"CYB-CERT-{event.id:03d}-{participant.id:05d}"
    pdf.setFont("Helvetica", 10)
    pdf.drawString(66, 78, f"Certificate No: {certificate_number}")
    if event.venue:
        pdf.drawString(66, 61, f"Venue: {event.venue}")

    qr_buffer = make_qr_png(verification_url)
    pdf.drawImage(ImageReader(qr_buffer), width - 145, 55, 72, 72)
    pdf.setFont("Helvetica", 8)
    pdf.drawCentredString(width - 109, 46, "Scan to verify")

    pdf.showPage()
    pdf.save()
    buffer.seek(0)
    return buffer, certificate_number
